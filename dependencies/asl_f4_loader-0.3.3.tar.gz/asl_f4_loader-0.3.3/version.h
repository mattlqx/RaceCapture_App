#ifndef _VERSION_H_
#define _VERSION_H_

#define VER_MAJOR 0
#define VER_MINOR 3
#define VER_BUGFIX 3

#endif
